/**
 * AUIGrid 1.5x License
 * License Type : Dev-Server License
 * Authorized Domain : *
 * Expiration Date : 2015/12/31
 */
var AUIGridLicense = "U2FsdGVkX19n9E1rhQoCtCch0hdu1A3utLgnv1wHWAEd7/aMSZH/9ae66I2ai6ccLs1vb1WBU7Y8/Ax4s2WGr6AsPir+GUzxbnS7HgRHyoQ=";